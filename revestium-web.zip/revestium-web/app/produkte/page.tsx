'use client'

import { useLang } from '@/lib/lang-context'
import Link from 'next/link'

const products = [
  {
    key: 'goldbank',
    label: 'Digitale Plattform',
    title: 'Gold Bank CZ · SK · EU',
    logo: '/images/loga_gb.jpg',
    desc: 'Die erste europäische Plattform, die physisches Gold mit der vollständigen Digitalisierung des gesamten Lebenszyklus verbindet. Kunden kaufen, verwalten und lagern Gold — direkt vom Smartphone oder Computer aus.',
    url: 'https://play.google.com/store/apps/dev?id=6089401306367412658&hl=cs',
    tags: ['+10 % p.a. in Au (vertraglich)', 'LBMA Good Delivery', 'Kreditkonto CZK & EUR', 'iOS · Android · Web'],
  },
  {
    key: 'aurom',
    label: 'Proprietär KI-Treasury & Research',
    title: 'AUROM & AUROM PRO — Dealer Commander',
    logo: '/images/aurom.jpg',
    desc: 'Eigenentwickeltes Forschungs- und Analysesystem für die Verwaltung und Neugewichtung von Portfolios mithilfe von KI: tägliche SARIMA/Prophet-Prognose, Smart Hedging CME + OTC, Yield-Hunter-Strategie, Stresstests.',
    url: 'https://dealer-commander-c54af5a9.base44.app/login',
    tags: ['Hedging CME + OTC', 'B2B SaaS', 'Net ROI +23 %', 'Proprietär · Live'],
  },
  {
    key: 'argus',
    label: 'Compliance & Intelligence',
    title: 'ARGUS & ARGUS PRO — AML/KYC Platform',
    logo: '/images/arguspro.jpg',
    desc: 'Fortschrittliche Plattform für AML/KYC-Vorschriften für den Edelmetallhandel. AI-OSINT-Analyse, Netzwerkbeziehungsdiagramm, interaktive Zeitleiste, automatische Risikobewertung.',
    url: undefined,
    tags: ['FATF · AMLD5 · DSGVO', 'ISO 27001', 'LBMA Responsible Sourcing', 'Ab 1.7.2027 verpflichtend'],
  },
  {
    key: 'digisavings',
    label: 'Digitales Sparprogramm',
    title: 'DIGI GOLD Savings',
    logo: undefined,
    desc: 'Digitales Programm für die physische Verwahrung von Edelmetallen. Schrittweiser Aufbau eines physischen Goldbestands — vollständig digital, 100 % physisch durch LBMA gedeckt, mit automatischer DCA-Optimierung.',
    url: 'https://digigold.cz/auth',
    tags: ['ab 50 EUR/Monat', '100 % physisch LBMA-gedeckt', 'DCA-Optimierung'],
  },
  {
    key: 'd10',
    label: 'Strukturiertes Beteiligungsprogramm',
    title: 'GOLD D10',
    logo: undefined,
    desc: 'Einzigartiges partizipatives Renditeprogramm mit einem bedeutenden Anteil an aktiven Handelsaktivitäten, das nicht als kollektives Anlageprogramm oder AIF-Fondsstruktur eingestuft ist.',
    url: 'https://www.golddeposit.net/',
    tags: ['10 diversifizierte Positionen', 'Kein AIF · kein Fonds', 'HNWI · qualif. Anleger'],
  },
  {
    key: 'goldcard',
    label: 'Zahlungsmittel · Täglich',
    title: 'Gold Card',
    logo: undefined,
    desc: 'Verbindung des Goldkontos bei der Gold Bank mit einer Mastercard — weltweit mit Gold zahlen. Transaktionen werden automatisch vom Goldguthaben abgezogen. Gold wird zu einer lebendigen Währung.',
    url: 'https://create.vista.com/cs/share/68bf22a9bb11ec234faa8a88',
    tags: ['Mastercard', 'Weltweit · täglich', '0 EU-Konkurrenten'],
  },
]

export default function ProduktePage() {
  const { tr } = useLang()

  return (
    <>
      {/* Header */}
      <div style={{
        paddingTop: 'calc(var(--nav-h) + 80px)', paddingBottom: '80px',
        background: 'linear-gradient(180deg, var(--dark2) 0%, var(--dark) 100%)',
        borderBottom: '1px solid var(--border)',
      }}>
        <div className="section-inner">
          <p className="section-label">{tr.produkte.label}</p>
          <h1 className="section-title">{tr.produkte.title}</h1>
          <div className="divider" />
          <p className="section-subtitle">{tr.produkte.subtitle}</p>
        </div>
      </div>

      {/* Products */}
      <section style={{ padding: '80px 0' }}>
        <div className="section-inner">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
            {products.map((p, i) => (
              <div
                key={p.key}
                className={`card${p.url ? ' clickable-card' : ''}`}
                onClick={p.url ? () => window.open(p.url, '_blank') : undefined}
                style={{ display: 'grid', gridTemplateColumns: p.logo ? 'auto 1fr' : '1fr', gap: '28px', alignItems: 'start' }}
              >
                {p.logo && (
                  <img src={p.logo} alt={p.title}
                    style={{ height: '60px', width: 'auto', borderRadius: '6px', flexShrink: 0 }} />
                )}
                <div>
                  <div className="card-label">{p.label}</div>
                  <div className="card-title" style={{ fontSize: '1.1rem' }}>{p.title}</div>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', lineHeight: 1.75, marginBottom: '14px' }}>
                    {p.desc}
                  </p>
                  <div className="card-meta">
                    {p.tags.map((tag, j) => (
                      <span key={j} className="meta-tag">{tag}</span>
                    ))}
                    {p.url && (
                      <span className="meta-tag" style={{ color: 'var(--gold)', borderColor: 'var(--border)' }}>
                        ↗ Öffnen
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '80px 0', background: 'var(--dark2)' }}>
        <div className="section-inner" style={{ textAlign: 'center' }}>
          <h2 className="section-title">Bereit für eine Partnerschaft?</h2>
          <p style={{ color: 'var(--text-muted)', marginBottom: '32px' }}>
            Sprechen Sie uns an — für institutionelle Anfragen, Integrationsoptionen und Lizenzmodelle.
          </p>
          <Link href="/kontakt" className="btn-primary">Kontakt aufnehmen →</Link>
        </div>
      </section>
    </>
  )
}
