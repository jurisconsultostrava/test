'use client'

import { useLang } from '@/lib/lang-context'

const entities = [
  {
    flag: '🇨🇭 Schweiz',
    name: 'REVESTIUM AG',
    logo: '/images/revestiumlogo.png',
    data: [
      { k: 'Adresse', v: 'Baarerstrasse 25, 6300 Zug, Schweiz' },
      { k: 'UID', v: 'CHE-383.245.411' },
      { k: 'Tel.', v: '+41 215 120 554' },
      { k: 'Director', v: 'Dr. iur. Marcus Altenburg' },
    ],
  },
  {
    flag: '🇬🇧 United Kingdom',
    name: 'JURISCONSULT LTD',
    logo: undefined,
    data: [
      { k: 'Adresse', v: '124 City Road, London, EC1V 2NX, UK' },
      { k: 'Companies House', v: '12729220' },
      { k: 'UTR', v: '5076723030' },
      { k: 'Tel.', v: '+44 7704 494 137' },
      { k: 'LEI', v: '315700UZ1Y9WYP99U441' },
      { k: 'SIC', v: '32120 · 46720 · 47770 · 64991' },
    ],
  },
  {
    flag: '🇮🇪 Ireland',
    name: 'SWISS GOLD DEPOSIT Ltd',
    logo: undefined,
    data: [
      { k: 'Adresse', v: "The Black Church, St. Mary's Place, Dublin 7, D07 P4ax" },
      { k: 'Reg. Number', v: '802415' },
    ],
  },
  {
    flag: '🇨🇿 Tschechische Republik',
    name: 'JURISCONSULT LTD o.z.',
    logo: undefined,
    data: [
      { k: 'Adresse', v: 'Praha, Tschechische Republik' },
      { k: 'IČ', v: '09913840' },
      { k: 'LEI', v: '315700343MOJGZ62NN31' },
      { k: 'Tel.', v: '+420 800 300 555' },
    ],
  },
]

export default function ImpressumPage() {
  const { tr } = useLang()

  return (
    <>
      <div style={{
        paddingTop: 'calc(var(--nav-h) + 80px)', paddingBottom: '60px',
        background: 'linear-gradient(180deg, var(--dark2) 0%, var(--dark) 100%)',
        borderBottom: '1px solid var(--border)',
        textAlign: 'center',
      }}>
        <div className="section-inner">
          <p className="section-label">{tr.impressum.label}</p>
          <h1 className="section-title">{tr.impressum.title}</h1>
          <div className="divider" style={{ margin: '16px auto 0' }} />
        </div>
      </div>

      <section style={{ padding: '80px 0' }}>
        <div className="section-inner">
          {/* Entities */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '48px' }}>
            {entities.map((e, i) => (
              <div key={i} className="entity-card">
                {e.logo && (
                  <img src={e.logo} alt={e.name}
                    style={{ height: '42px', width: 'auto', marginBottom: '16px', display: 'block', mixBlendMode: 'screen' }} />
                )}
                {!e.logo && (
                  <div style={{ height: '42px', marginBottom: '16px', display: 'flex', alignItems: 'center' }}>
                    <span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'rgba(196,149,74,0.9)' }}>{e.name.split(' ')[0]}</span>
                  </div>
                )}
                <div className="entity-flag">{e.flag}</div>
                <div className="entity-name">{e.name}</div>
                <div className="entity-data">
                  {e.data.map((d, j) => (
                    <div key={j}><span>{d.k}:</span> {d.v}<br /></div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Augustina */}
          <div style={{
            background: 'rgba(196,149,74,0.04)',
            border: '1px solid rgba(196,149,74,0.12)',
            borderRadius: 'var(--r)',
            padding: '24px 32px',
            marginBottom: '48px',
            display: 'flex',
            alignItems: 'center',
            gap: '24px',
            flexWrap: 'wrap',
          }}>
            <img src="/images/augustina-portrait.png"
              alt="Mag. iur. Augustina F. Schiller MSc., LLM."
              style={{ width: '80px', height: '80px', borderRadius: '50%', objectFit: 'cover', flexShrink: 0, border: '2px solid rgba(196,149,74,0.35)', mixBlendMode: 'screen' }} />
            <div style={{ flex: 1, minWidth: '200px' }}>
              <div style={{ fontSize: '10px', letterSpacing: '3px', color: 'rgba(196,149,74,0.65)', textTransform: 'uppercase', marginBottom: '6px' }}>
                Global Verwaltungsratspräsidentin
              </div>
              <div style={{ fontSize: '1.05rem', fontWeight: 600, color: '#fff', marginBottom: '4px' }}>
                Mag. iur. Augustina F. Schiller MSc., LLM.
              </div>
              <div style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.8rem' }}>
                CEO & Owner · Jurisconsult Ltd · REVESTIUM Group
              </div>
            </div>
          </div>

          {/* AML bilingual */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '48px' }}>
            <div className="aml-box">
              <p className="aml-label">{tr.impressum.amlTitle}</p>
              <p className="aml-text">
                The company enters into business relationships and conducts transactions exclusively with partners based in the European Union, Switzerland, and the United Kingdom, which are considered low-risk jurisdictions under the Swiss Anti-Money Laundering Act (AMLA / GwG) and FATF assessments, given its full membership and implementation of international AML/CFT frameworks.
              </p>
              <p className="aml-text" style={{ marginBottom: 0 }}>
                The company strictly refrains from conducting business with natural or legal persons from high-risk third countries, as defined in European Commission Regulation (EU) 2016/1675 (as amended) and in the list of high-risk jurisdictions subject to a call for action issued by the FATF.
              </p>
            </div>
            <div className="aml-box">
              <p className="aml-label">{tr.impressum.amlTitleDe}</p>
              <p className="aml-text">
                Das Unternehmen geht Geschäftsbeziehungen ein und wickelt Transaktionen ausschließlich mit Partnern ab, die ihren Sitz in der Europäischen Union, der Schweiz und dem Vereinigten Königreich haben. Diese Länder gelten gemäß dem Schweizer Geldwäschereigesetz (GwG) und den Bewertungen der FATF als Länder mit geringem Risiko.
              </p>
              <p className="aml-text" style={{ marginBottom: 0 }}>
                Das Unternehmen verzichtet strikt auf Geschäfte mit natürlichen oder juristischen Personen aus Hochrisikoländern, wie sie in der Verordnung (EU) 2016/1675 der Europäischen Kommission definiert sind. Bei all seinen Geschäften hält sich REVESTIUM strikt an diese internationalen Compliance-Standards.
              </p>
            </div>
          </div>

          {/* Copyright */}
          <div style={{ borderTop: '1px solid rgba(196,149,74,0.12)', paddingTop: '28px' }}>
            <p style={{ color: 'rgba(255,255,255,0.38)', fontSize: '0.75rem', lineHeight: 2 }}>
              {tr.footer.rights} {tr.footer.note}<br />
              <span style={{ opacity: 0.7 }}>{tr.footer.note2}</span>
            </p>
          </div>
        </div>
      </section>
    </>
  )
}
