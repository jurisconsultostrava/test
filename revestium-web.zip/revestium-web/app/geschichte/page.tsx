'use client'

import { useLang } from '@/lib/lang-context'

export default function GeschichtePage() {
  const { tr } = useLang()

  return (
    <>
      <div style={{
        paddingTop: 'calc(var(--nav-h) + 80px)', paddingBottom: '80px',
        background: 'linear-gradient(180deg, var(--dark2) 0%, var(--dark) 100%)',
        borderBottom: '1px solid var(--border)',
      }}>
        <div className="section-inner">
          <p className="section-label">{tr.geschichte.label}</p>
          <h1 className="section-title">{tr.geschichte.title}</h1>
          <div className="divider" />
        </div>
      </div>

      <section style={{ padding: '80px 0' }}>
        <div className="section-inner">
          <div className="grid-2" style={{ gap: '60px', alignItems: 'start', marginBottom: '80px' }}>
            {/* Left column */}
            <div>
              <p style={{ color: 'var(--text-muted)', lineHeight: 1.85, fontSize: '0.92rem', marginBottom: '16px' }}>
                {tr.geschichte.text1}
              </p>
              <blockquote style={{
                borderLeft: '3px solid var(--gold)',
                paddingLeft: '20px',
                fontStyle: 'italic',
                fontSize: '1.1rem',
                color: 'rgba(255,255,255,0.75)',
                margin: '24px 0',
              }}>
                {tr.geschichte.quote}
              </blockquote>
              <p style={{ color: 'var(--text-muted)', lineHeight: 1.85, fontSize: '0.92rem', marginBottom: '32px' }}>
                {tr.geschichte.text2}
              </p>

              {/* Signature */}
              <div style={{ marginTop: '32px' }}>
                <img src="/images/vizitka-signature.png"
                  alt="Augustina F. Schiller — Unterschrift"
                  style={{ width: '100%', maxWidth: '100%', height: 'auto', display: 'block', opacity: 0.95, mixBlendMode: 'screen' }} />
              </div>
            </div>

            {/* Right column — timeline */}
            <div className="timeline">
              {tr.geschichte.timeline.map((item, i) => (
                <div key={i} className="tl-item">
                  <div className="tl-dot" />
                  <div className="tl-year">{item.year}</div>
                  <div className="tl-title">{item.title}</div>
                  <div className="tl-desc">{item.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Jurisdictions */}
          <p className="section-label">{tr.geschichte.timelineLabel}</p>
          <h2 className="section-title">{tr.geschichte.jurisdictionsTitle}</h2>
          <div className="divider" />

          <div className="grid-4">
            {[
              { flag: '🇨🇭', title: 'REVESTIUM AG — Zug', desc: 'Holding & Tokenisierung · Gegründet 2020' },
              { flag: '🇬🇧', title: 'JURISCONSULT LTD — London', desc: 'LEI: 315700UZ1Y9WYP99U441 · CH: 12729220' },
              { flag: '🇮🇪', title: 'SWISS GOLD DEPOSIT — Dublin', desc: 'Bereit zur Zulassung in allen 27 EU-Mitgliedstaaten · MiFID II' },
              { flag: '🇨🇿', title: 'MOJE ZLATO — Jurisconsult o.z.', desc: 'LEI: 315700343MOJGZ62NN31 · Czech Assay Office Lizenz' },
            ].map((j, i) => (
              <div key={i} className="card">
                <div className="card-label">{j.flag}</div>
                <div className="card-title">{j.title}</div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{j.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
