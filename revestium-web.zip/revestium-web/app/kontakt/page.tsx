'use client'

import { useState } from 'react'
import { useLang } from '@/lib/lang-context'

export default function KontaktPage() {
  const { tr } = useLang()
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    // Simulate send (replace with actual API call)
    await new Promise(r => setTimeout(r, 1200))
    setLoading(false)
    setSent(true)
  }

  return (
    <>
      <div style={{
        paddingTop: 'calc(var(--nav-h) + 80px)', paddingBottom: '80px',
        background: 'linear-gradient(180deg, var(--dark2) 0%, var(--dark) 100%)',
        borderBottom: '1px solid var(--border)',
      }}>
        <div className="section-inner">
          <p className="section-label">{tr.kontakt.label}</p>
          <h1 className="section-title">{tr.kontakt.title}</h1>
          <div className="divider" />
          <p className="section-subtitle">{tr.kontakt.subtitle}</p>
        </div>
      </div>

      <section style={{ padding: '80px 0' }}>
        <div className="section-inner">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '60px', alignItems: 'start' }}>

            {/* Contact info */}
            <div>
              <div className="card" style={{ marginBottom: '24px' }}>
                <div className="card-label">🇨🇭 REVESTIUM AG</div>
                <div className="card-title">Hauptsitz</div>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem', lineHeight: 2 }}>
                  Baarerstrasse 25<br />
                  6300 Zug, Schweiz<br />
                  <span style={{ color: 'var(--gold)' }}>UID:</span> CHE-383.245.411<br />
                  <a href="tel:+41215120554" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>+41 215 120 554</a>
                </div>
              </div>
              <div className="card" style={{ marginBottom: '24px' }}>
                <div className="card-label">🇬🇧 JURISCONSULT LTD</div>
                <div className="card-title">London</div>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem', lineHeight: 2 }}>
                  124 City Road<br />
                  London, EC1V 2NX<br />
                  <a href="tel:+447704494137" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>+44 7704 494 137</a>
                </div>
              </div>
              <div className="card">
                <div className="card-label">🇨🇿 JURISCONSULT o.z.</div>
                <div className="card-title">Praha</div>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem', lineHeight: 2 }}>
                  Praha, Tschechische Republik<br />
                  <a href="tel:+420800300555" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>+420 800 300 555</a>
                </div>
              </div>
              <div style={{ marginTop: '24px' }}>
                <a href="mailto:info@revestium.ch" className="btn-primary" style={{ display: 'inline-flex' }}>
                  info@revestium.ch →
                </a>
              </div>
            </div>

            {/* Form */}
            <div>
              {sent ? (
                <div style={{
                  background: 'rgba(196,149,74,0.08)',
                  border: '1px solid rgba(196,149,74,0.3)',
                  borderRadius: 'var(--r)',
                  padding: '48px',
                  textAlign: 'center',
                }}>
                  <div style={{ fontSize: '2rem', marginBottom: '16px' }}>✓</div>
                  <div style={{ fontSize: '1.1rem', fontWeight: 600, color: '#fff', marginBottom: '8px' }}>
                    Nachricht gesendet
                  </div>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    Wir melden uns innerhalb von 24 Stunden.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">{tr.kontakt.name} *</label>
                      <input className="form-input" required
                        value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">{tr.kontakt.email} *</label>
                      <input type="email" className="form-input" required
                        value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="form-label">{tr.kontakt.subject}</label>
                    <select className="form-select"
                      value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}>
                      <option value="">— Bitte wählen —</option>
                      {tr.kontakt.subjects.map((s, i) => (
                        <option key={i} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">{tr.kontakt.message} *</label>
                    <textarea className="form-textarea" required
                      value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} />
                  </div>
                  <button type="submit" className="btn-primary" disabled={loading}
                    style={{ width: '100%', justifyContent: 'center', opacity: loading ? 0.7 : 1 }}>
                    {loading ? '...' : tr.kontakt.send}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
