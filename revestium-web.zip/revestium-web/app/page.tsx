'use client'

import dynamic from 'next/dynamic'
import Link from 'next/link'
import { useLang } from '@/lib/lang-context'

const MatrixRain = dynamic(() => import('@/components/MatrixRain'), { ssr: false })

export default function HomePage() {
  const { tr } = useLang()

  return (
    <>
      {/* ── HERO ── */}
      <section id="home" style={{
        position: 'relative',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        paddingTop: 'var(--nav-h)',
        backgroundImage: "url('/images/hero-bg.jpg')",
        backgroundSize: 'cover',
        backgroundPosition: 'center center',
        backgroundRepeat: 'no-repeat',
      }}>
        {/* Overlay */}
        <div style={{
          position: 'absolute', inset: 0, zIndex: 0,
          background: 'radial-gradient(ellipse at center, rgba(4,6,14,0.65) 0%, rgba(4,6,14,0.82) 60%, rgba(4,6,14,0.92) 100%)',
        }} />

        <MatrixRain />

        <div style={{
          position: 'relative', zIndex: 1,
          width: '100%', maxWidth: '1100px',
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          textAlign: 'center',
          padding: '80px 60px',
        }}>
          <p style={{
            fontSize: '1.6rem', letterSpacing: '0.04em', color: 'var(--gold)',
            textTransform: 'uppercase', marginBottom: '10px', opacity: 0.9, fontWeight: 300,
          }}>
            {tr.hero.eyebrow}
          </p>

          <h1 style={{
            fontFamily: "'Arimo', sans-serif",
            fontSize: 'clamp(2.56rem, 5.12vw, 6.08rem)',
            fontWeight: 400,
            lineHeight: 1.0,
            letterSpacing: '0.22em',
            color: 'var(--gold-hero)',
            textTransform: 'uppercase',
            marginTop: '36px',
            marginBottom: '36px',
            whiteSpace: 'nowrap',
          }}>
            GOLD{' '}
            <span style={{ fontWeight: 400, letterSpacing: '0.18em', color: 'var(--gold-hero)' }}>as a</span>
            {' '}
            <span style={{ color: 'var(--gold-hero)', textTransform: 'uppercase' }}>SERVICE</span>
          </h1>

          <p style={{
            fontSize: '1.05rem', fontWeight: 500,
            color: 'rgba(255,255,255,0.75)',
            maxWidth: '700px', marginBottom: '36px', lineHeight: 1.7,
          }}>
            {tr.hero.subtitle}
          </p>

          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '40px', justifyContent: 'center' }}>
            {tr.hero.badges.map((b, i) => (
              <span key={i} className="badge">{b}</span>
            ))}
          </div>

          <Link href="/produkte" className="btn-primary">
            {tr.hero.cta} →
          </Link>
        </div>
      </section>

      {/* ── OVERVIEW CARDS ── */}
      <section style={{ padding: '100px 0', background: 'var(--dark2)' }}>
        <div className="section-inner">
          <p className="section-label">Das Ökosystem</p>
          <h2 className="section-title">Alle Produkte — eine gemeinsame Engine</h2>
          <div className="divider" />

          <div className="grid-3" style={{ marginBottom: '48px' }}>
            {[
              { label: '🟢 Live', title: 'Gold Bank CZ · SK · EU', desc: '38 Depots · EUR 9,1M AuM · +10 % p.a. · iOS · Android · Web', url: 'https://play.google.com/store/apps/dev?id=6089401306367412658&hl=cs' },
              { label: '🟢 Live · proprietär', title: 'AUROM Dealer Commander', desc: 'AI Treasury · SARIMA · CME Hedging · OTC · Net ROI +23 %', url: 'https://dealer-commander-c54af5a9.base44.app/login' },
              { label: '🟢 Live', title: 'Edelmetalle Retail & Wholesale', desc: '150+ Produkte · LBMA Good Delivery · Kunstjuwelier · Bespoke', url: undefined },
              { label: '⏳ Rollout', title: 'GOLD D10', desc: '10 diversifizierte Positionen · Kein AIF · HNWI · Qual. Anleger', url: 'https://www.golddeposit.net/' },
              { label: '⏳ Rollout', title: 'ARGUS AML/KYC Platform', desc: 'FATF · AMLD5 · DSGVO · LBMA Responsible Sourcing · AI OSINT', url: undefined },
              { label: '🔵 Ready to launch', title: 'Gold Hypo & Gold Repo', desc: '5–20 Jahre / 1–12 Monate · LTV 80 % · T+2 · Kooperativa', url: undefined },
              { label: '🔵 Ready to launch', title: 'Gold Card Mastercard', desc: 'Weltweit · täglich · Gold als lebendige Währung · 0 EU-Konkurrenten', url: 'https://create.vista.com/cs/share/68bf22a9bb11ec234faa8a88' },
              { label: '⏳ Rollout', title: 'DIGI GOLD Savings', desc: 'ab 50 EUR/Monat · 100 % physisch LBMA-gedeckt · DCA-Optimierung', url: 'https://digigold.cz/auth' },
              { label: '⚪ Roadmap 2026–27', title: 'Gold as Collateral · PGI', desc: 'OTC Margining · Triparty · Intraday · WGC · Linklaters · LBMA', url: undefined },
            ].map((card, i) => (
              <div
                key={i}
                className={`card${card.url ? ' clickable-card' : ''}`}
                onClick={card.url ? () => window.open(card.url, '_blank') : undefined}
              >
                <div className="card-label">{card.label}</div>
                <div className="card-title">{card.title}</div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{card.desc}</p>
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center' }}>
            <Link href="/produkte" className="btn-outline">Alle Produkte →</Link>
          </div>
        </div>
      </section>

      {/* ── RATING TEASER ── */}
      <section id="rating" style={{ padding: '100px 0' }}>
        <div className="section-inner">
          <p className="section-label">Bonität & Vertrauen</p>
          <h2 className="section-title">Dun & Bradstreet Rating</h2>
          <div className="divider" />

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '40px', alignItems: 'start' }}>
            <div>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', lineHeight: 1.8, marginBottom: '24px' }}>
                JURISCONSULT LTD. o.z. wird durch Dun & Bradstreet mit dem Rating <strong style={{ color: 'var(--gold)' }}>H1</strong> und einem Gesamtrisiko „niedrig" bewertet.
              </p>
              <div className="rating-card">
                <div className="rating-big">H1</div>
                <div className="rating-label">D&B Rating · Risiko: Niedrig</div>
                <div className="db-grid">
                  <div className="db-item"><div className="db-val">H</div><div className="db-key">Finanzielle Stärke</div></div>
                  <div className="db-item"><div className="db-val">1</div><div className="db-key">Risiko-Indikator</div></div>
                  <div className="db-item"><div className="db-val">95</div><div className="db-key">Failure Score</div></div>
                  <div className="db-item"><div className="db-val">3 %</div><div className="db-key">Delinquency Prob.</div></div>
                </div>
              </div>

              {/* Partner logos */}
              <div style={{ marginTop: '28px' }}>
                <p style={{ fontSize: '0.72rem', letterSpacing: '3px', textTransform: 'uppercase', color: 'rgba(196,149,74,0.65)', marginBottom: '16px' }}>
                  Mitgliedschaften & Partner
                </p>
                <div className="partner-logos">
                  <img src="/images/ipmi.png" alt="IPMI" style={{ height: '72px', width: 'auto', mixBlendMode: 'screen' }} />
                  <img src="/images/lbma.png" alt="LBMA" style={{ height: '72px', width: 'auto', mixBlendMode: 'screen' }} />
                  <img src="/images/akc.png" alt="akcenta" style={{ height: '65px', width: 'auto', mixBlendMode: 'screen' }} />
                </div>
              </div>
            </div>

            <div>
              <div className="card" style={{ marginBottom: '20px' }}>
                <div className="card-label">Strategie & Ausblick</div>
                <div className="card-title">Was sind unsere Pläne für die Zukunft?</div>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.75 }}>
                  Langfristig werden regulatorische Entwicklungen, ESG-Standards, Transparenz in der Lieferkette sowie die Digitalisierung von Handels- und Verwahrungsprozessen eine entscheidende Rolle spielen. Dank unserer Mitgliedschaft im IPMI und unserem Engagement bei der LBMA sind wir Teil eines globalen Netzwerks.
                </p>
              </div>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                <Link href="/geschichte" className="btn-outline">Geschichte →</Link>
                <Link href="/kontakt" className="btn-primary">Kontakt →</Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
